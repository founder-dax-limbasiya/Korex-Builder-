// ============================================================
// KOREX BUILDER — Health Check API Route
// ============================================================
// GET /api/health
//
// Returns the status of all services:
// - Groq API connection
// - Environment variable presence (not values — just present/missing)
//
// Safe to call from the frontend — no secrets are exposed.
// ============================================================

import { NextResponse } from 'next/server';
import { checkGroqHealth } from '@/lib/groq.server';

export async function GET() {
  const checks = {
    // Check that required env vars are set (never expose their values)
    env: {
      groqApiKey:          !!process.env.GROQ_API_KEY,
      supabaseUrl:         !!process.env.NEXT_PUBLIC_SUPABASE_URL,
      supabaseAnonKey:     !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
    },

    // Check Groq API connectivity
    groq: { ok: false, model: '', latency: 0 },

    // Timestamp
    timestamp: new Date().toISOString(),
  };

  // Test Groq connection (quick test with minimal tokens)
  if (checks.env.groqApiKey) {
    checks.groq = await checkGroqHealth();
  }

  const allHealthy = checks.env.groqApiKey && checks.groq.ok;

  return NextResponse.json(checks, { status: allHealthy ? 200 : 503 });
}
