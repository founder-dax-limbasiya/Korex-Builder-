// ============================================================
// KOREX BUILDER — Main Generation API Route
// ============================================================
// POST /api/generate
//
// This is the ONLY server-side endpoint that touches the Groq
// API. The GROQ_API_KEY never leaves this file.
// Users call this endpoint from the frontend — they only ever
// see their generated code, never the API key or raw response.
//
// Request body:
//   { templateId, tierId, description }
//
// Response body:
//   { files, summary, features, setup_steps, env_vars, meta }
//
// HOW TO MODIFY VIA AI PROMPT:
// "Add request logging to a Supabase table"
// "Cache identical requests for 1 hour to save API calls"
// "Add a webhook that fires when generation completes"
// ============================================================

import { NextRequest, NextResponse } from 'next/server';
import { generateWithGroq } from '@/lib/groq.server';
import { buildGenerationPrompt, type TemplateId, type TierId } from '@/lib/prompt-builder';
import { parseGenerationResponse } from '@/lib/response-parser';
import { checkRateLimit, getClientIp } from '@/lib/rate-limiter';

// ── Request Validation ────────────────────────────────────────
const VALID_TEMPLATES: TemplateId[] = ['portfolio', 'saas', 'ecommerce', 'crm', 'blog', 'custom'];
const VALID_TIERS: TierId[]         = ['basic', 'pro', 'enterprise'];

// ── POST Handler ──────────────────────────────────────────────
export async function POST(request: NextRequest) {
  const requestStart = Date.now();

  try {
    // ── Step 1: Rate limiting check ────────────────────────────
    const clientIp = getClientIp(request);
    const rateLimit = checkRateLimit(clientIp);

    if (!rateLimit.allowed) {
      return NextResponse.json(
        {
          error: 'rate_limit_exceeded',
          message: `You've used your generation quota. Please wait ${rateLimit.resetInMin} minute${rateLimit.resetInMin === 1 ? '' : 's'} before generating again.`,
          resetInMin: rateLimit.resetInMin,
        },
        {
          status: 429,
          headers: {
            'X-RateLimit-Remaining': '0',
            'X-RateLimit-Reset': String(rateLimit.resetInMs),
          },
        }
      );
    }

    // ── Step 2: Parse and validate request body ────────────────
    let body: { templateId?: unknown; tierId?: unknown; description?: unknown };
    try {
      body = await request.json();
    } catch {
      return NextResponse.json(
        { error: 'invalid_request', message: 'Request body must be valid JSON.' },
        { status: 400 }
      );
    }

    const { templateId, tierId, description } = body;

    // Validate templateId
    if (!templateId || !VALID_TEMPLATES.includes(templateId as TemplateId)) {
      return NextResponse.json(
        {
          error: 'invalid_template',
          message: `templateId must be one of: ${VALID_TEMPLATES.join(', ')}`,
        },
        { status: 400 }
      );
    }

    // Validate tierId
    if (!tierId || !VALID_TIERS.includes(tierId as TierId)) {
      return NextResponse.json(
        {
          error: 'invalid_tier',
          message: `tierId must be one of: ${VALID_TIERS.join(', ')}`,
        },
        { status: 400 }
      );
    }

    // Sanitize description (limit length to prevent prompt injection attacks)
    const safeDescription = String(description ?? '').slice(0, 1000);

    // ── Step 3: Build AI prompt ────────────────────────────────
    const { systemPrompt, userMessage } = buildGenerationPrompt({
      templateId: templateId as TemplateId,
      tierId:     tierId as TierId,
      userDescription: safeDescription,
    });

    // ── Step 4: Call Groq (with automatic retry & fallback) ────
    console.log(`[API] Generating ${tierId} tier ${templateId} app for IP: ${clientIp}`);

    const groqResult = await generateWithGroq({ systemPrompt, userMessage });

    // ── Step 5: Parse the AI response ─────────────────────────
    const parsedResult = parseGenerationResponse(groqResult.content, templateId as string);

    // ── Step 6: Return success response ───────────────────────
    const totalTime = Date.now() - requestStart;

    return NextResponse.json(
      {
        ...parsedResult,
        // Meta info (visible in browser dev tools, useful for debugging)
        meta: {
          model:          groqResult.model,
          tokensUsed:     groqResult.tokensUsed,
          generationTime: groqResult.generationTime,
          totalTime,
          templateId,
          tierId,
        },
      },
      {
        status: 200,
        headers: {
          'X-RateLimit-Remaining': String(rateLimit.remaining),
          'X-Generation-Time':     String(totalTime),
          'X-Model-Used':          groqResult.model,
        },
      }
    );

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred.';

    console.error('[API] Generation error:', errorMessage);

    // Return a friendly error — never expose internal details to the client
    return NextResponse.json(
      {
        error: 'generation_failed',
        message: errorMessage.includes('rate limit')
          ? errorMessage // This is safe to show (it's our own message)
          : 'Generation failed. The AI service may be temporarily busy. Please try again in a moment.',
      },
      { status: 500 }
    );
  }
}

// ── OPTIONS handler for CORS preflight ───────────────────────
export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin':  '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  });
}
