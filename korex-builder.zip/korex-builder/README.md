# Korex Builder 🔮

**Zero-Cost AI Full-Stack App Engine** — Generate production-ready Next.js apps in seconds.

No API key required from users. No setup complexity. Just type and build.

---

## What Is This?

Korex Builder is a web app that generates complete, production-ready Next.js applications using AI.
You describe what you want, click Generate, and get back:

- ✅ **Frontend** — React components with Tailwind CSS
- ✅ **Backend** — Next.js API routes with CRUD operations
- ✅ **Database** — Supabase PostgreSQL schema (SQL ready to run)
- ✅ **Deployment** — `vercel.json` config for one-click deploy
- ✅ **Docs** — Setup instructions tailored to your app

**Zero-Cost Stack:**
| Service | Plan | Cost |
|---------|------|------|
| [Vercel](https://vercel.com) | Hobby | Free |
| [Supabase](https://supabase.com) | Free Tier | Free |
| [Groq](https://console.groq.com) | Free API | Free |

---

## Quick Setup (5 Minutes)

### Step 1 — Clone & Install

```bash
git clone https://github.com/your-username/korex-builder
cd korex-builder
npm install
```

### Step 2 — Get Your Free Groq API Key

1. Go to [console.groq.com](https://console.groq.com)
2. Sign up (free, no credit card needed)
3. Click **API Keys** → **Create API Key**
4. Copy your key

### Step 3 — Configure Environment

```bash
cp .env.example .env.local
```

Open `.env.local` and fill in your values:

```env
# Required: Your Groq API key (stays server-side, users never see it)
GROQ_API_KEY=gsk_your_key_here

# Optional: Supabase (only needed if you want to save generation history)
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key_here
```

### Step 4 — Run Locally

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) — Korex Builder is running!

---

## Deploy to Vercel (One Click)

1. Push your code to GitHub
2. Go to [vercel.com/new](https://vercel.com/new)
3. Import your repository
4. Add environment variables in the Vercel dashboard (Settings → Environment Variables):
   - `GROQ_API_KEY` = your Groq key
5. Click **Deploy**

That's it — your app is live and free!

---

## Project Structure

```
korex-builder/
├── app/
│   ├── api/
│   │   ├── generate/
│   │   │   └── route.ts      ← The hidden AI gateway (Groq API key lives here)
│   │   └── health/
│   │       └── route.ts      ← Health check endpoint
│   ├── globals.css            ← Global styles & animations
│   ├── layout.tsx             ← Root layout with fonts
│   └── page.tsx               ← Main page (orchestrates everything)
│
├── components/
│   ├── ui/
│   │   └── AnimatedBackground.tsx   ← Decorative background layer
│   ├── builder/
│   │   ├── BuildPanel.tsx           ← Template/tier/description selection
│   │   └── GenerationLoader.tsx     ← Animated loading screen
│   └── output/
│       └── OutputPanel.tsx          ← Generated code viewer & downloader
│
├── config/
│   └── app.config.ts          ← ALL app settings in one place (easy to modify!)
│
├── lib/
│   ├── groq.server.ts         ← Groq client (SERVER ONLY — key never exposed)
│   ├── prompt-builder.ts      ← Builds AI prompts for each template/tier
│   ├── rate-limiter.ts        ← IP-based rate limiting (protects your quota)
│   └── response-parser.ts     ← Safely parses AI JSON responses
│
├── .env.example               ← Template for environment variables
├── next.config.js             ← Next.js configuration
├── tailwind.config.js         ← Tailwind CSS configuration
├── vercel.json                ← One-click Vercel deployment config
└── README.md                  ← This file
```

---

## Customization Guide (No Code Required!)

The easiest way to customize Korex Builder is to use an AI assistant (like Claude or ChatGPT).
Just paste the relevant file and say what you want changed.

### Examples:

**Add a new app template:**
> "Look at `config/app.config.ts`. Add a new template called 'Landing Page' with icon ◆, color #06b6d4, and a description about marketing pages."

**Change the AI model:**
> "In `config/app.config.ts`, change the PRIMARY model to `llama-3.1-70b-versatile`."

**Increase rate limit:**
> "In `config/app.config.ts`, change RATE_LIMIT.PER_HOUR from 10 to 25."

**Add a new generation tier:**
> "In `lib/prompt-builder.ts`, add a new 'mobile' tier that generates React Native code."

---

## Security

- 🔒 `GROQ_API_KEY` is only ever accessed in `lib/groq.server.ts` and `app/api/generate/route.ts`
- 🔒 Server files never ship to the browser
- 🔒 All user input is sanitized and length-limited before reaching the AI
- 🔒 Rate limiting prevents quota exhaustion
- 🔒 No user data is stored unless you add Supabase logging

---

## FAQ

**Q: Is this really free forever?**
A: Yes. Vercel Hobby, Supabase Free Tier, and Groq's free API are all genuinely free with no credit card needed. The only cost is if your usage exceeds free-tier limits (which is unlikely for personal use).

**Q: What happens if Groq rate-limits me?**
A: The app automatically retries with fallback models (Llama-3.1-70b → Llama-3-8b). Users see a smooth loading animation throughout — no error walls.

**Q: Can I add my own AI provider?**
A: Yes. Modify `lib/groq.server.ts` to use any OpenAI-compatible API. The rest of the app doesn't change.

**Q: Is the generated code production-ready?**
A: It's a solid starting point. Treat it like a well-structured scaffold — review, test, and customize before shipping to production.

---

## License

MIT — do whatever you want with this. Build something great.
