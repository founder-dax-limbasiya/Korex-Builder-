// ============================================================
// KOREX BUILDER — AI Prompt Engineering Module
// ============================================================
// This file builds the detailed prompts that instruct the AI
// exactly what code to generate and in what format.
//
// HOW TO MODIFY VIA AI PROMPT:
// "Update the enterprise tier to also generate Dockerfile"
// "Add a 'mobile app' tier that generates React Native code"
// "Change the output format to include inline code comments"
// ============================================================

import { APP_TEMPLATES } from '@/config/app.config';

// ── Types ─────────────────────────────────────────────────────
export type TierId = 'basic' | 'pro' | 'enterprise';
export type TemplateId = 'portfolio' | 'saas' | 'ecommerce' | 'crm' | 'blog' | 'custom';

export interface PromptInput {
  templateId: TemplateId;
  tierId: TierId;
  userDescription: string; // What the user typed in the description box
}

// ── What each tier generates ──────────────────────────────────
const TIER_INSTRUCTIONS: Record<TierId, string> = {

  basic: `
DELIVERABLE: A single production-ready React component file.
- One file: app/page.tsx
- Beautiful UI using Tailwind CSS classes
- Dark theme, modern design
- Include loading states and empty states
- Fully responsive (mobile-first)
`.trim(),

  pro: `
DELIVERABLE: Three production-ready files.
1. app/page.tsx — Complete React frontend page
2. app/api/[resource]/route.ts — Next.js API route with GET, POST, PUT, DELETE handlers
3. database/schema.sql — Supabase PostgreSQL schema with tables, indexes, and Row Level Security policies

Each file must be complete and immediately usable.
`.trim(),

  enterprise: `
DELIVERABLE: Six complete, production-ready files.
1. app/page.tsx — Full React frontend with all components
2. app/api/[resource]/route.ts — Complete CRUD API route handlers
3. app/api/auth/route.ts — Supabase Auth integration (sign up, sign in, sign out)
4. database/schema.sql — Full PostgreSQL schema with RLS policies, triggers, and seed data
5. vercel.json — Complete Vercel deployment configuration
6. README.md — Clear setup guide with step-by-step instructions for non-developers

Every file must be complete, well-commented, and immediately deployable.
`.trim(),
};

// ── Shared coding standards applied to all tiers ─────────────
const CODING_STANDARDS = `
CODING STANDARDS (apply to all files):
- Language: TypeScript with proper interfaces and types
- Styling: Tailwind CSS utility classes (assume it's configured)
- UI Theme: Dark background (#0a0a0f), neon accents, glassmorphism cards
- State: React hooks (useState, useEffect, useCallback)
- API calls: Use fetch() with proper error handling and loading states
- Database: @supabase/supabase-js client
- Error handling: Try/catch on all async operations, user-friendly error messages
- Responsive: Mobile-first with Tailwind breakpoints (sm: md: lg:)
- Accessibility: Proper aria labels, semantic HTML, keyboard navigation
`.trim();

// ── Output format instructions ────────────────────────────────
const OUTPUT_FORMAT = `
OUTPUT FORMAT — Return ONLY a valid JSON object. No markdown. No extra text. No code fences.
Use this exact structure:

{
  "files": [
    {
      "filename": "app/page.tsx",
      "language": "typescript",
      "description": "One sentence describing this file's purpose",
      "code": "// Complete file code here — no truncation"
    }
  ],
  "summary": "2-3 sentence description of what was built and its key features",
  "features": ["Feature 1", "Feature 2", "Feature 3", "Feature 4", "Feature 5"],
  "setup_steps": [
    "Step 1: Run npm install",
    "Step 2: Copy .env.example to .env.local and fill in values",
    "Step 3: Run npx supabase db push to apply the schema",
    "Step 4: Run npm run dev"
  ],
  "env_vars": ["NEXT_PUBLIC_SUPABASE_URL", "NEXT_PUBLIC_SUPABASE_ANON_KEY"]
}

CRITICAL: The "code" fields must contain the COMPLETE file contents — never truncate or use placeholders.
`.trim();

// ── Main Prompt Builder ───────────────────────────────────────
/**
 * Builds the system and user prompts for a generation request.
 * Combines template context + tier instructions + coding standards.
 *
 * @param input - Template type, tier, and user's description
 * @returns { systemPrompt, userMessage } ready to send to Groq
 */
export function buildGenerationPrompt(input: PromptInput): {
  systemPrompt: string;
  userMessage: string;
} {
  const { templateId, tierId, userDescription } = input;

  // Find the template config (for default description)
  const template = APP_TEMPLATES.find(t => t.id === templateId);
  const effectiveDescription = userDescription.trim() || template?.defaultDescription || `A ${templateId} application`;

  // ── System Prompt: Tells the AI WHO it is and HOW to behave ──
  const systemPrompt = `
You are Korex Builder, an expert full-stack engineer specializing in Next.js 14 (App Router), 
TypeScript, Tailwind CSS, and Supabase. You generate complete, production-ready code — never 
placeholders, never truncated output, never "// add your code here" comments.

Your code is clean, well-commented, and structured so a non-developer could hand it to an AI 
assistant later and say "update X" and have it work immediately.

${CODING_STANDARDS}

${TIER_INSTRUCTIONS[tierId]}

${OUTPUT_FORMAT}
`.trim();

  // ── User Message: The specific build request ──────────────────
  const userMessage = `
Build a ${tierId.toUpperCase()} tier ${templateId.toUpperCase()} application.

User's Requirements:
${effectiveDescription}

Additional Context:
- This will be deployed on Vercel (Hobby/Free tier)
- Database: Supabase (Free tier — PostgreSQL)
- The app must look polished and professional out of the box
- Include realistic placeholder data/content so it looks populated

Generate the complete ${tierId} tier output now.
`.trim();

  return { systemPrompt, userMessage };
}
