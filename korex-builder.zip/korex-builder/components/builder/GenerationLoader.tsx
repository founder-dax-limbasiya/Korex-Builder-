// ============================================================
// KOREX BUILDER — Generation Loader
// ============================================================
// Shown during AI generation. Displays animated progress,
// phase messages, and the rotating Korex logo mark.
// This is what makes the "seamless experience" — users watch
// a satisfying progress animation instead of a blank screen.
//
// HOW TO MODIFY VIA AI PROMPT:
// "Add a list of tips that rotate during generation"
// "Show a live token counter during generation"
// ============================================================

'use client';

interface GenerationLoaderProps {
  phase: string;       // Current phase message e.g. "Building API routes…"
  progress: number;    // 0–100 progress percentage
}

export default function GenerationLoader({ phase, progress }: GenerationLoaderProps) {
  return (
    <div
      className="glass animate-fade-in"
      style={{
        borderRadius: '16px',
        padding: '56px 40px',
        textAlign: 'center',
        maxWidth: '540px',
        margin: '0 auto',
      }}
    >
      {/* ── Korex Logo with Pulse Rings ─────────────────── */}
      <div style={{ position: 'relative', width: 88, height: 88, margin: '0 auto 32px' }}>
        {/* Outer pulse ring */}
        <div style={{
          position: 'absolute', inset: 0, borderRadius: '50%',
          border: '1.5px solid var(--neon-green)',
          animation: 'pulseRing 1.6s ease-out infinite',
        }} />

        {/* Inner pulse ring (offset) */}
        <div style={{
          position: 'absolute', inset: 0, borderRadius: '50%',
          border: '1.5px solid var(--neon-blue)',
          animation: 'pulseRing 1.6s 0.6s ease-out infinite',
        }} />

        {/* Spinning dashed ring */}
        <div style={{
          position: 'absolute', inset: '8px', borderRadius: '50%',
          border: '1px dashed rgba(0,245,180,0.3)',
          animation: 'rotate 4s linear infinite',
        }} />

        {/* Center logo badge */}
        <div style={{
          position: 'absolute', inset: '22px', borderRadius: '50%',
          background: 'linear-gradient(135deg, var(--neon-green), var(--neon-blue))',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: '18px', fontWeight: 900, color: '#020408',
          fontFamily: 'var(--font-display)',
          boxShadow: 'var(--glow-green)',
        }}>
          K
        </div>
      </div>

      {/* ── Status Label ────────────────────────────────── */}
      <div style={{
        fontFamily: 'var(--font-display)', fontSize: '12px', letterSpacing: '0.12em',
        marginBottom: '10px',
      }} className="neon-green animate-flicker">
        KOREX ENGINE ACTIVE
      </div>

      {/* ── Phase Message ────────────────────────────────── */}
      <div style={{
        fontFamily: 'var(--font-mono)', fontSize: '13px', color: 'var(--text-dim)',
        marginBottom: '32px', minHeight: '20px', lineHeight: 1.5,
      }}>
        {phase}
        <span className="animate-blink" style={{ color: 'var(--neon-green)' }}>█</span>
      </div>

      {/* ── Progress Bar ─────────────────────────────────── */}
      <div style={{ maxWidth: '360px', margin: '0 auto 12px' }}>
        <div style={{
          background: 'rgba(255,255,255,0.05)',
          borderRadius: '6px',
          height: '5px',
          overflow: 'hidden',
          border: '1px solid rgba(255,255,255,0.06)',
        }}>
          <div style={{
            height: '100%',
            borderRadius: '6px',
            width: `${progress}%`,
            background: 'linear-gradient(90deg, var(--neon-green), var(--neon-blue))',
            transition: 'width 0.6s ease',
            boxShadow: '0 0 12px rgba(0,245,180,0.6)',
            position: 'relative',
          }}>
            {/* Shimmer on progress bar */}
            <div style={{
              position: 'absolute', inset: 0,
              background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent)',
              animation: 'shimmer 1.5s linear infinite',
              backgroundSize: '200% 100%',
            }} />
          </div>
        </div>
      </div>

      {/* ── Progress Percentage ───────────────────────────── */}
      <div style={{
        fontFamily: 'var(--font-display)', fontSize: '11px', letterSpacing: '0.1em',
        color: 'var(--neon-green)',
      }}>
        {progress}%
      </div>

      {/* ── Disclaimer ───────────────────────────────────── */}
      <div style={{
        marginTop: '28px', padding: '12px 16px', borderRadius: '8px',
        background: 'rgba(0,245,180,0.04)', border: '1px solid rgba(0,245,180,0.1)',
        fontSize: '11px', fontFamily: 'var(--font-mono)', color: 'var(--text-dim)',
        lineHeight: 1.5,
      }}>
        Generating complete, production-ready code — this takes 10–30 seconds.
      </div>
    </div>
  );
}
