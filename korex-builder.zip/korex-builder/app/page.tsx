// ============================================================
// KOREX BUILDER — Main Page (app/page.tsx)
// ============================================================
// This is the root page. It orchestrates:
//   - Global state (template, tier, description, results)
//   - API call to /api/generate (no API key in the browser!)
//   - Phase animation during generation
//   - Switching between Build and Output panels
//
// HOW TO MODIFY VIA AI PROMPT:
// "Add a history panel that shows past generations"
// "Add a share button that copies a permalink to the result"
// "Add a dark/light mode toggle to the header"
// ============================================================

'use client';

import { useState, useCallback, useRef, useEffect } from 'react';
import AnimatedBackground from '@/components/ui/AnimatedBackground';
import BuildPanel from '@/components/builder/BuildPanel';
import GenerationLoader from '@/components/builder/GenerationLoader';
import OutputPanel from '@/components/output/OutputPanel';
import { GENERATION_PHASES } from '@/config/app.config';
import type { ParsedGenerationResult } from '@/lib/response-parser';

// ── Types ─────────────────────────────────────────────────────
type AppView = 'build' | 'generating' | 'output';

interface GenerationMeta {
  model: string;
  tokensUsed: number;
  generationTime: number;
  totalTime: number;
  templateId: string;
  tierId: string;
}

// ── Page Component ─────────────────────────────────────────────
export default function HomePage() {
  // ── Build Configuration State ────────────────────────────
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [selectedTier,     setSelectedTier]     = useState<string>('pro');
  const [description,      setDescription]      = useState<string>('');

  // ── View State ────────────────────────────────────────────
  const [view, setView] = useState<AppView>('build');

  // ── Generation Progress State ─────────────────────────────
  const [phaseMessage,  setPhaseMessage]  = useState<string>('');
  const [phaseProgress, setPhaseProgress] = useState<number>(0);

  // ── Result State ──────────────────────────────────────────
  const [result, setResult] = useState<ParsedGenerationResult | null>(null);
  const [meta,   setMeta]   = useState<GenerationMeta | null>(null);
  const [error,  setError]  = useState<string | null>(null);

  // ── Ref to scroll to output ───────────────────────────────
  const outputRef = useRef<HTMLDivElement>(null);

  // ── Phase Animator ────────────────────────────────────────
  // Cycles through phase messages during generation
  const runPhaseAnimation = useCallback(() => {
    let phaseIndex = 0;

    const interval = setInterval(() => {
      if (phaseIndex < GENERATION_PHASES.length) {
        setPhaseMessage(GENERATION_PHASES[phaseIndex].message);
        setPhaseProgress(GENERATION_PHASES[phaseIndex].progress);
        phaseIndex++;
      }
    }, 900); // Advance phase every 900ms

    return interval; // Return so we can clear it
  }, []);

  // ── Main Generation Handler ───────────────────────────────
  const handleGenerate = useCallback(async () => {
    if (!selectedTemplate) return;

    // Reset state and switch to loading view
    setError(null);
    setResult(null);
    setMeta(null);
    setView('generating');
    setPhaseProgress(0);
    setPhaseMessage(GENERATION_PHASES[0].message);

    // Start phase animation
    const phaseInterval = runPhaseAnimation();

    try {
      // ── Call our hidden server-side API route ────────────
      // The GROQ_API_KEY stays on the server — users never see it
      const response = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          templateId:  selectedTemplate,
          tierId:      selectedTier,
          description: description.trim(),
        }),
      });

      const data = await response.json();

      // Clear animation
      clearInterval(phaseInterval);

      // ── Handle error responses ───────────────────────────
      if (!response.ok) {
        // Rate limit: friendly message with countdown
        if (response.status === 429) {
          setError(data.message ?? 'Rate limit reached. Please try again soon.');
          setView('build');
          return;
        }

        throw new Error(data.message ?? `Server error: ${response.status}`);
      }

      // ── Success: show results ────────────────────────────
      setPhaseMessage('Complete! Your app is ready.');
      setPhaseProgress(100);

      // Small delay for the "100%" moment to register
      await sleep(600);

      setResult({
        files:       data.files       ?? [],
        summary:     data.summary     ?? '',
        features:    data.features    ?? [],
        setup_steps: data.setup_steps ?? [],
        env_vars:    data.env_vars    ?? [],
      });

      setMeta(data.meta ?? null);
      setView('output');

    } catch (err: unknown) {
      clearInterval(phaseInterval);

      const message = err instanceof Error
        ? err.message
        : 'An unexpected error occurred. Please try again.';

      setError(message);
      setView('build');
    }
  }, [selectedTemplate, selectedTier, description, runPhaseAnimation]);

  // ── Reset to start a new generation ──────────────────────
  const handleReset = useCallback(() => {
    setView('build');
    setResult(null);
    setMeta(null);
    setError(null);
    setSelectedTemplate(null);
    setDescription('');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  // ── Scroll to output when it appears ──────────────────────
  useEffect(() => {
    if (view === 'output' && outputRef.current) {
      setTimeout(() => {
        outputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 150);
    }
  }, [view]);

  return (
    <div style={{ position: 'relative', minHeight: '100vh', paddingBottom: '80px' }}>
      <AnimatedBackground />

      {/* ── Content Layer ────────────────────────────────── */}
      <div style={{ position: 'relative', zIndex: 1 }}>

        {/* ── Header ─────────────────────────────────────── */}
        <header style={{
          padding: '28px 32px 0',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        }} className="animate-fade-up">
          <div style={{ display: 'flex', alignItems: 'center', gap: '14px' }}>
            {/* Logo */}
            <div style={{
              width: 44, height: 44, borderRadius: '10px', flexShrink: 0,
              background: 'linear-gradient(135deg, var(--neon-green), var(--neon-blue))',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: '18px', fontWeight: 900, color: '#020408',
              fontFamily: 'var(--font-display)',
              boxShadow: 'var(--glow-green)',
            }}>
              K
            </div>
            <div>
              <div style={{
                fontFamily: 'var(--font-display)', fontSize: '15px',
                fontWeight: 700, letterSpacing: '0.14em',
              }} className="neon-green">
                KOREX BUILDER
              </div>
              <div style={{
                fontSize: '9px', color: 'var(--text-dim)',
                fontFamily: 'var(--font-mono)', letterSpacing: '0.1em',
              }}>
                ZERO-COST AI APP ENGINE
              </div>
            </div>
          </div>

          {/* Pills — hidden on mobile */}
          <div style={{ display: 'flex', gap: '8px' }}>
            {['FREE FOREVER', 'NO API KEY', 'FULL-STACK', 'OPEN SOURCE'].map(tag => (
              <div key={tag} style={{
                padding: '4px 10px', borderRadius: '20px',
                border: '1px solid var(--border)',
                fontSize: '9px', fontFamily: 'var(--font-mono)',
                letterSpacing: '0.1em', color: 'var(--text-dim)',
                display: window?.innerWidth > 768 ? undefined : 'none',
              }}>
                {tag}
              </div>
            ))}
          </div>
        </header>

        {/* ── Hero Section ───────────────────────────────── */}
        <div style={{ textAlign: 'center', padding: '48px 24px 36px' }} className="animate-fade-up">
          {/* Top badge */}
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: '8px',
            padding: '5px 16px', borderRadius: '20px', marginBottom: '20px',
            background: 'rgba(0,245,180,0.07)', border: '1px solid rgba(0,245,180,0.2)',
            fontSize: '10px', fontFamily: 'var(--font-mono)', letterSpacing: '0.14em',
            color: 'var(--neon-green)',
          }}>
            <span style={{ display: 'inline-block', width: 6, height: 6, borderRadius: '50%', background: 'var(--neon-green)', boxShadow: '0 0 6px var(--neon-green)' }} />
            POWERED BY GROQ + DEEPSEEK · TYPE & BUILD · NO SETUP REQUIRED
          </div>

          {/* Main headline */}
          <h1 style={{
            fontFamily: 'var(--font-display)', fontWeight: 900, lineHeight: 1.08,
            fontSize: 'clamp(28px, 6vw, 64px)', marginBottom: '16px', letterSpacing: '-0.01em',
          }}>
            <span className="shimmer-text">BUILD FULL-STACK APPS</span>
            <br />
            <span style={{ color: 'rgba(232,234,240,0.65)' }}>IN SECONDS. FREE.</span>
          </h1>

          {/* Sub-headline */}
          <p style={{
            fontSize: 'clamp(13px, 2vw, 16px)', color: 'var(--text-dim)',
            maxWidth: '520px', margin: '0 auto 0',
            fontFamily: 'var(--font-body)', lineHeight: 1.75,
          }}>
            Generate production-ready Next.js apps — complete frontend, API routes,
            Supabase schema, and Vercel config — with zero cost, zero setup, and no API key.
          </p>
        </div>

        {/* ── Tab Navigation (only shown when not generating) ── */}
        {view !== 'generating' && (
          <div style={{ display: 'flex', justifyContent: 'center', gap: '8px', marginBottom: '32px' }}>
            {[
              { id: 'build',  label: '⬟ BUILD' },
              { id: 'output', label: '◈ OUTPUT', disabled: !result },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => !tab.disabled && setView(tab.id as AppView)}
                disabled={tab.disabled}
                style={{
                  padding: '8px 28px', borderRadius: '8px', cursor: tab.disabled ? 'default' : 'pointer',
                  border: `1px solid ${view === tab.id ? 'rgba(0,245,180,0.4)' : 'var(--border)'}`,
                  background: view === tab.id ? 'rgba(0,245,180,0.08)' : 'transparent',
                  fontFamily: 'var(--font-mono)', fontSize: '11px', letterSpacing: '0.08em',
                  color: view === tab.id ? 'var(--neon-green)' : tab.disabled ? 'rgba(232,234,240,0.2)' : 'var(--text-dim)',
                  transition: 'all 0.2s',
                }}
              >
                {tab.label}
              </button>
            ))}
          </div>
        )}

        {/* ── Error Banner ───────────────────────────────── */}
        {error && view === 'build' && (
          <div style={{
            maxWidth: '860px', margin: '0 auto 20px', padding: '0 20px',
          }}>
            <div style={{
              padding: '16px 20px', borderRadius: '10px',
              background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.25)',
              fontFamily: 'var(--font-mono)', fontSize: '12px', color: '#fca5a5',
              display: 'flex', alignItems: 'flex-start', gap: '10px',
            }}>
              <span style={{ fontSize: '14px', flexShrink: 0 }}>⚠</span>
              <span style={{ lineHeight: 1.5 }}>{error}</span>
              <button
                onClick={() => setError(null)}
                style={{ marginLeft: 'auto', background: 'none', border: 'none', color: '#fca5a5', cursor: 'pointer', flexShrink: 0 }}
              >
                ✕
              </button>
            </div>
          </div>
        )}

        {/* ── Panel Router ───────────────────────────────── */}
        {view === 'build' && (
          <BuildPanel
            selectedTemplate={selectedTemplate}
            selectedTier={selectedTier}
            description={description}
            isGenerating={false}
            onTemplateSelect={setSelectedTemplate}
            onTierSelect={setSelectedTier}
            onDescriptionChange={setDescription}
            onGenerate={handleGenerate}
          />
        )}

        {view === 'generating' && (
          <div style={{ padding: '20px' }}>
            <GenerationLoader phase={phaseMessage} progress={phaseProgress} />
          </div>
        )}

        {view === 'output' && result && (
          <div ref={outputRef}>
            <OutputPanel result={result} meta={meta ?? undefined} onReset={handleReset} />
          </div>
        )}

      </div>
    </div>
  );
}

// ── Utility ───────────────────────────────────────────────────
function sleep(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
