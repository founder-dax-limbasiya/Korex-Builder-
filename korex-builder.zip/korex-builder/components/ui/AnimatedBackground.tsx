// ============================================================
// KOREX BUILDER — Animated Background
// ============================================================
// Fixed-position decorative background layer.
// Contains: grid lines, scan line, glow orbs, noise overlay.
// This is pure visual — no logic here.
// ============================================================

'use client';

export default function AnimatedBackground() {
  return (
    <div
      aria-hidden="true"
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 0,
        overflow: 'hidden',
        pointerEvents: 'none',
      }}
    >
      {/* ── Perspective grid ───────────────────────────────── */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          backgroundImage: `
            linear-gradient(rgba(0,245,180,0.04) 1px, transparent 1px),
            linear-gradient(90deg, rgba(0,245,180,0.04) 1px, transparent 1px)
          `,
          backgroundSize: '60px 60px',
          animation: 'gridPulse 4s ease-in-out infinite',
        }}
      />

      {/* ── Horizontal scan line ───────────────────────────── */}
      <div
        style={{
          position: 'absolute',
          left: 0,
          right: 0,
          height: '2px',
          background: 'linear-gradient(90deg, transparent, rgba(0,245,180,0.12), rgba(0,200,255,0.08), transparent)',
          animation: 'scan 10s linear infinite',
        }}
      />

      {/* ── Top-right glow blob (blue) ─────────────────────── */}
      <div
        style={{
          position: 'absolute',
          top: '-20%',
          right: '-10%',
          width: '55vw',
          height: '55vw',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(0,200,255,0.07) 0%, transparent 70%)',
        }}
      />

      {/* ── Bottom-left glow blob (violet) ─────────────────── */}
      <div
        style={{
          position: 'absolute',
          bottom: '-25%',
          left: '-15%',
          width: '65vw',
          height: '65vw',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(168,85,247,0.07) 0%, transparent 70%)',
        }}
      />

      {/* ── Center glow blob (green, subtle) ──────────────── */}
      <div
        style={{
          position: 'absolute',
          top: '35%',
          left: '25%',
          width: '50vw',
          height: '50vw',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(0,245,180,0.04) 0%, transparent 70%)',
        }}
      />

      {/* ── Noise grain overlay ────────────────────────────── */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          opacity: 0.025,
          backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='1'/%3E%3C/svg%3E")`,
          backgroundRepeat: 'repeat',
          backgroundSize: '128px 128px',
        }}
      />
    </div>
  );
}
