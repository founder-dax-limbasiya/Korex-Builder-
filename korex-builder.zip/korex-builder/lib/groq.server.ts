// ============================================================
// KOREX BUILDER — Groq AI Client (SERVER-SIDE ONLY)
// ============================================================
// This module runs ONLY on the server (Next.js API routes).
// The GROQ_API_KEY is NEVER sent to the browser.
// Users interact with /api/generate — they never see this file.
//
// HOW TO MODIFY VIA AI PROMPT:
// "Update the Groq client to use model X instead of Y"
// "Add response caching to reduce API calls"
// "Change the temperature to 0.5 for more creative output"
// ============================================================

import Groq from 'groq-sdk';
import { GROQ_MODELS, GENERATION_CONFIG } from '@/config/app.config';

// ── Singleton Groq client instance ───────────────────────────
// We create one instance and reuse it (saves memory & connection time)
let groqClient: Groq | null = null;

/**
 * Returns a configured Groq client.
 * Throws a clear error if the API key is missing.
 */
function getGroqClient(): Groq {
  if (groqClient) return groqClient; // Return existing instance if available

  const apiKey = process.env.GROQ_API_KEY;

  if (!apiKey) {
    throw new Error(
      'GROQ_API_KEY is not set. Add it to your .env.local file or Vercel environment variables.'
    );
  }

  groqClient = new Groq({ apiKey });
  return groqClient;
}

// ── Types ─────────────────────────────────────────────────────
export interface GenerationRequest {
  systemPrompt: string;   // The detailed instructions for the AI
  userMessage: string;    // The user's specific request
  maxTokens?: number;     // Override token limit if needed
}

export interface GenerationResult {
  content: string;        // Raw text response from the AI
  model: string;          // Which model was actually used
  tokensUsed: number;     // How many tokens were consumed
  generationTime: number; // How long it took in milliseconds
}

// ── Core Generation Function ──────────────────────────────────
/**
 * Sends a request to Groq and returns the generated text.
 * Automatically retries with fallback models if rate-limited.
 * This is the ONLY place in the app that touches the Groq API.
 *
 * @param request - What to generate and how
 * @returns The generated content and metadata
 */
export async function generateWithGroq(request: GenerationRequest): Promise<GenerationResult> {
  const client = getGroqClient();
  const startTime = Date.now();

  // Try models in order: primary → fallback → emergency
  const modelsToTry = [
    GROQ_MODELS.PRIMARY,
    GROQ_MODELS.FALLBACK,
    GROQ_MODELS.EMERGENCY,
  ];

  let lastError: Error | null = null;

  for (const model of modelsToTry) {
    // Retry each model up to MAX_RETRIES times
    for (let attempt = 1; attempt <= GENERATION_CONFIG.MAX_RETRIES; attempt++) {
      try {
        console.log(`[Groq] Trying model: ${model} (attempt ${attempt}/${GENERATION_CONFIG.MAX_RETRIES})`);

        const response = await client.chat.completions.create({
          model,
          max_tokens: request.maxTokens ?? GENERATION_CONFIG.MAX_TOKENS,
          temperature: GENERATION_CONFIG.TEMPERATURE,
          messages: [
            { role: 'system', content: request.systemPrompt },
            { role: 'user',   content: request.userMessage  },
          ],
        });

        // Extract the generated text
        const content = response.choices[0]?.message?.content ?? '';
        const tokensUsed = response.usage?.total_tokens ?? 0;
        const generationTime = Date.now() - startTime;

        console.log(`[Groq] Success — model: ${model}, tokens: ${tokensUsed}, time: ${generationTime}ms`);

        return { content, model, tokensUsed, generationTime };

      } catch (error: unknown) {
        lastError = error instanceof Error ? error : new Error(String(error));
        const errorMessage = lastError.message.toLowerCase();

        // If rate-limited, wait before retrying
        if (errorMessage.includes('rate_limit') || errorMessage.includes('429')) {
          const waitTime = GENERATION_CONFIG.RETRY_DELAY_MS * attempt;
          console.warn(`[Groq] Rate limited on ${model}. Waiting ${waitTime}ms before retry…`);
          await sleep(waitTime);
          continue; // Retry same model
        }

        // If model not found or quota exceeded, try next model immediately
        if (errorMessage.includes('model_not_found') || errorMessage.includes('quota')) {
          console.warn(`[Groq] Model ${model} unavailable. Trying next fallback…`);
          break; // Exit retry loop, move to next model
        }

        // Unknown error — log and retry
        console.error(`[Groq] Unexpected error on ${model}:`, lastError.message);
        if (attempt < GENERATION_CONFIG.MAX_RETRIES) {
          await sleep(GENERATION_CONFIG.RETRY_DELAY_MS);
        }
      }
    }
  }

  // All models failed — throw a user-friendly error
  throw new Error(
    `Generation failed after trying all available models. ` +
    `This is usually a temporary rate limit. Please try again in 30 seconds. ` +
    `(Technical detail: ${lastError?.message ?? 'Unknown error'})`
  );
}

// ── Helper Functions ──────────────────────────────────────────

/** Pauses execution for a given number of milliseconds */
function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Health check — verifies the Groq connection is working.
 * Used by the /api/health endpoint.
 */
export async function checkGroqHealth(): Promise<{ ok: boolean; model: string; latency: number }> {
  const start = Date.now();
  try {
    const result = await generateWithGroq({
      systemPrompt: 'You are a health check system.',
      userMessage:  'Reply with just the word: OK',
      maxTokens:    10,
    });
    return { ok: true, model: result.model, latency: Date.now() - start };
  } catch {
    return { ok: false, model: 'none', latency: Date.now() - start };
  }
}
