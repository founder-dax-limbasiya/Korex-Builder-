// ============================================================
// KOREX BUILDER — Build Configuration Panel
// ============================================================
// The left/main panel where users:
//   1. Choose a tier (Basic / Pro / Enterprise)
//   2. Select an app template
//   3. Optionally describe their app
//   4. Hit "Generate"
//
// HOW TO MODIFY VIA AI PROMPT:
// "Add a 'color theme' selector to the build panel"
// "Add a character counter to the description textarea"
// "Show estimated generation time next to each tier"
// ============================================================

'use client';

import { APP_TEMPLATES, TIERS } from '@/config/app.config';

// ── Types ─────────────────────────────────────────────────────
interface BuildPanelProps {
  selectedTemplate: string | null;
  selectedTier: string;
  description: string;
  isGenerating: boolean;
  onTemplateSelect: (id: string) => void;
  onTierSelect:     (id: string) => void;
  onDescriptionChange: (value: string) => void;
  onGenerate: () => void;
}

// ── Component ─────────────────────────────────────────────────
export default function BuildPanel({
  selectedTemplate,
  selectedTier,
  description,
  isGenerating,
  onTemplateSelect,
  onTierSelect,
  onDescriptionChange,
  onGenerate,
}: BuildPanelProps) {

  return (
    <div className="animate-fade-up" style={{ maxWidth: '860px', margin: '0 auto', padding: '0 20px' }}>

      {/* ── Tier Selection ────────────────────────────────── */}
      <SectionLabel icon="◎" label="SELECT TIER" />
      <div style={{ display: 'flex', gap: '10px', flexWrap: 'wrap', marginBottom: '28px' }}>
        {TIERS.map(tier => {
          const isActive = selectedTier === tier.id;
          return (
            <button
              key={tier.id}
              onClick={() => onTierSelect(tier.id)}
              style={{
                flex: '1 1 160px',
                padding: '16px',
                borderRadius: '12px',
                cursor: 'pointer',
                border: `1px solid ${isActive ? tier.color : 'var(--border)'}`,
                background: isActive ? `${tier.color}10` : 'var(--surface)',
                transition: 'all 0.2s ease',
                textAlign: 'left',
                position: 'relative',
                overflow: 'hidden',
              }}
            >
              {/* Active glow accent */}
              {isActive && (
                <div style={{
                  position: 'absolute', top: 0, left: 0, right: 0, height: '2px',
                  background: `linear-gradient(90deg, transparent, ${tier.color}, transparent)`,
                }} />
              )}

              {/* Badge */}
              {'badge' in tier && (
                <span style={{
                  position: 'absolute', top: '10px', right: '10px',
                  padding: '2px 8px', borderRadius: '10px',
                  fontSize: '8px', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em',
                  background: `${tier.color}20`, color: tier.color, border: `1px solid ${tier.color}40`,
                }}>
                  {(tier as typeof tier & { badge: string }).badge}
                </span>
              )}

              <div style={{
                fontFamily: 'var(--font-display)', fontSize: '11px', fontWeight: 700,
                letterSpacing: '0.1em', color: tier.color, marginBottom: '5px',
              }}>
                {tier.label}
              </div>
              <div style={{ fontSize: '11px', color: 'var(--text-dim)', fontFamily: 'var(--font-mono)', marginBottom: '8px' }}>
                {tier.desc}
              </div>

              {/* File list */}
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px' }}>
                {tier.files.map((file, i) => (
                  <span key={i} style={{
                    padding: '2px 6px', borderRadius: '4px', fontSize: '9px',
                    fontFamily: 'var(--font-mono)', background: 'rgba(255,255,255,0.04)',
                    color: 'var(--text-dim)', border: '1px solid var(--border)',
                  }}>
                    {file}
                  </span>
                ))}
              </div>
            </button>
          );
        })}
      </div>

      {/* ── Template Selection ────────────────────────────── */}
      <SectionLabel icon="✦" label="SELECT APP TYPE" />
      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(195px, 1fr))',
        gap: '10px',
        marginBottom: '28px',
      }}>
        {APP_TEMPLATES.map(template => {
          const isActive = selectedTemplate === template.id;
          return (
            <button
              key={template.id}
              onClick={() => onTemplateSelect(template.id)}
              style={{
                padding: '16px',
                borderRadius: '12px',
                cursor: 'pointer',
                textAlign: 'left',
                border: `1px solid ${isActive ? template.color : 'var(--border)'}`,
                background: isActive ? 'rgba(0,0,0,0.4)' : 'var(--surface)',
                transition: 'all 0.2s ease',
                position: 'relative',
                overflow: 'hidden',
              }}
              onMouseEnter={e => {
                if (!isActive) (e.currentTarget as HTMLElement).style.background = 'var(--surface-hover)';
              }}
              onMouseLeave={e => {
                if (!isActive) (e.currentTarget as HTMLElement).style.background = 'var(--surface)';
              }}
            >
              {/* Radial glow on active */}
              {isActive && (
                <div style={{
                  position: 'absolute', inset: 0, pointerEvents: 'none',
                  background: `radial-gradient(circle at top left, ${template.color}12, transparent 70%)`,
                }} />
              )}

              {/* Top accent line */}
              {isActive && (
                <div style={{
                  position: 'absolute', top: 0, left: 0, right: 0, height: '2px',
                  background: template.color, opacity: 0.7,
                }} />
              )}

              <div style={{
                fontSize: '22px', marginBottom: '8px',
                filter: isActive ? `drop-shadow(0 0 8px ${template.color})` : 'none',
                transition: 'filter 0.2s',
              }}>
                {template.icon}
              </div>

              <div style={{
                fontFamily: 'var(--font-body)', fontWeight: 700, fontSize: '13px',
                marginBottom: '4px',
                color: isActive ? template.color : 'var(--text)',
                transition: 'color 0.2s',
              }}>
                {template.label}
              </div>

              <div style={{ fontSize: '11px', color: 'var(--text-dim)', fontFamily: 'var(--font-mono)' }}>
                {template.desc}
              </div>
            </button>
          );
        })}
      </div>

      {/* ── Description Input ─────────────────────────────── */}
      <SectionLabel icon="◇" label="DESCRIBE YOUR APP (OPTIONAL — BUT RECOMMENDED)" />
      <textarea
        value={description}
        onChange={e => onDescriptionChange(e.target.value)}
        maxLength={1000}
        placeholder={
          selectedTemplate
            ? APP_TEMPLATES.find(t => t.id === selectedTemplate)?.defaultDescription
            : 'Describe your app in detail — the more specific you are, the better the output. E.g. "A project management SaaS with Kanban boards, team invites, time tracking, and Stripe billing..."'
        }
        rows={4}
        style={{
          width: '100%',
          padding: '16px',
          borderRadius: '12px',
          background: 'rgba(0,0,0,0.35)',
          border: '1px solid var(--border)',
          color: 'var(--text)',
          fontFamily: 'var(--font-mono)',
          fontSize: '13px',
          lineHeight: '1.65',
          resize: 'vertical',
          transition: 'border-color 0.2s',
          marginBottom: '6px',
        }}
        onFocus={e => (e.target.style.borderColor = 'var(--border-bright)')}
        onBlur={e =>  (e.target.style.borderColor = 'var(--border)')}
      />
      <div style={{
        textAlign: 'right', fontSize: '10px', fontFamily: 'var(--font-mono)',
        color: 'var(--text-dim)', marginBottom: '28px',
      }}>
        {description.length}/1000
      </div>

      {/* ── Generate Button ───────────────────────────────── */}
      <button
        onClick={onGenerate}
        disabled={!selectedTemplate || isGenerating}
        style={{
          width: '100%',
          padding: '18px 32px',
          borderRadius: '12px',
          border: 'none',
          background: selectedTemplate && !isGenerating
            ? 'linear-gradient(135deg, var(--neon-green), var(--neon-blue))'
            : 'rgba(255,255,255,0.08)',
          color: selectedTemplate && !isGenerating ? '#020408' : 'var(--text-dim)',
          fontFamily: 'var(--font-display)',
          fontWeight: 700,
          fontSize: '13px',
          letterSpacing: '0.15em',
          cursor: selectedTemplate && !isGenerating ? 'pointer' : 'not-allowed',
          transition: 'all 0.25s ease',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          gap: '12px',
          boxShadow: selectedTemplate && !isGenerating ? 'var(--glow-green)' : 'none',
          marginBottom: '24px',
        }}
      >
        {isGenerating ? (
          <>
            <span style={{
              width: 16, height: 16,
              border: '2px solid rgba(255,255,255,0.3)',
              borderTopColor: 'white',
              borderRadius: '50%',
              display: 'inline-block',
              animation: 'rotate 0.8s linear infinite',
            }} />
            GENERATING YOUR APP…
          </>
        ) : !selectedTemplate ? (
          '← SELECT AN APP TYPE FIRST'
        ) : (
          `⚡ GENERATE ${selectedTier.toUpperCase()} TIER APP`
        )}
      </button>

      {/* ── Zero-Cost Stack Badges ────────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: '8px' }}>
        {[
          { icon: '▲', label: 'Vercel',      sub: 'Hobby (Free)',    color: 'var(--text-dim)' },
          { icon: '⬡', label: 'Supabase',    sub: 'Free Tier',       color: '#3ecf8e' },
          { icon: '◈', label: 'Groq AI',     sub: 'Free API',        color: 'var(--neon-green)' },
          { icon: '⬟', label: 'Next.js 14',  sub: 'App Router',      color: 'var(--neon-blue)' },
        ].map((s, i) => (
          <div key={i} className="glass" style={{ padding: '10px 14px', borderRadius: '8px', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <span style={{ color: s.color, fontSize: '16px', flexShrink: 0 }}>{s.icon}</span>
            <div>
              <div style={{ fontSize: '11px', fontWeight: 600, color: 'var(--text)' }}>{s.label}</div>
              <div style={{ fontSize: '9px', color: 'var(--text-dim)', fontFamily: 'var(--font-mono)' }}>{s.sub}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Reusable Section Label ────────────────────────────────────
function SectionLabel({ icon, label }: { icon: string; label: string }) {
  return (
    <div style={{
      fontSize: '10px',
      fontFamily: 'var(--font-mono)',
      letterSpacing: '0.14em',
      color: 'var(--text-dim)',
      marginBottom: '12px',
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
    }}>
      <span style={{ color: 'var(--neon-green)' }}>{icon}</span>
      {label}
    </div>
  );
}
