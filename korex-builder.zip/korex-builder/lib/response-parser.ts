// ============================================================
// KOREX BUILDER — AI Response Parser
// ============================================================
// Safely parses the JSON response from the AI model.
// Includes fallback logic so a partial response still works.
//
// HOW TO MODIFY VIA AI PROMPT:
// "Add validation to ensure all required fields are present"
// "Add a 'preview_url' field to the output structure"
// "Parse multi-file responses into a zip download"
// ============================================================

// ── Types ─────────────────────────────────────────────────────

export interface GeneratedFile {
  filename: string;     // e.g. "app/page.tsx"
  language: string;     // e.g. "typescript"
  description: string;  // One-line description of this file
  code: string;         // Complete file contents
}

export interface ParsedGenerationResult {
  files: GeneratedFile[];
  summary: string;
  features: string[];
  setup_steps: string[];
  env_vars: string[];
}

// ── Main Parser ───────────────────────────────────────────────
/**
 * Parses the raw text response from the AI into structured data.
 * Uses multiple strategies to extract valid JSON even from
 * imperfect responses.
 *
 * @param rawText - The raw string from the AI model
 * @param templateId - Used for fallback filename generation
 * @returns Structured generation result
 */
export function parseGenerationResponse(
  rawText: string,
  templateId: string = 'app'
): ParsedGenerationResult {
  
  // Strategy 1: Direct JSON parse (ideal case)
  try {
    const cleaned = rawText
      .replace(/^```json\s*/m, '') // Remove leading ```json
      .replace(/^```\s*/m, '')     // Remove leading ```
      .replace(/```\s*$/m, '')     // Remove trailing ```
      .trim();

    const parsed = JSON.parse(cleaned);
    return normalizeResult(parsed, templateId, rawText);

  } catch {
    // Strategy 1 failed — try extracting JSON from the middle of the text
  }

  // Strategy 2: Find JSON object within the response
  try {
    const jsonMatch = rawText.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return normalizeResult(parsed, templateId, rawText);
    }
  } catch {
    // Strategy 2 failed — use the raw text as a single code file
  }

  // Strategy 3: Fallback — treat entire response as code
  console.warn('[Parser] Could not parse JSON — using raw text fallback');
  return {
    files: [{
      filename: `app/page.tsx`,
      language: 'typescript',
      description: `Generated ${templateId} application`,
      code: rawText,
    }],
    summary: `Your ${templateId} application has been generated. The code is ready to use.`,
    features: ['Generated component', 'TypeScript support', 'Tailwind CSS styling'],
    setup_steps: [
      'Copy the generated code into your Next.js project',
      'Run npm install to install dependencies',
      'Run npm run dev to start the development server',
    ],
    env_vars: ['NEXT_PUBLIC_SUPABASE_URL', 'NEXT_PUBLIC_SUPABASE_ANON_KEY'],
  };
}

// ── Normalizer: Fills in missing fields with sensible defaults ─
function normalizeResult(
  parsed: Record<string, unknown>,
  templateId: string,
  rawText: string
): ParsedGenerationResult {
  
  return {
    files: Array.isArray(parsed.files) && parsed.files.length > 0
      ? (parsed.files as GeneratedFile[]).map(f => ({
          filename:    String(f.filename    ?? `${templateId}.tsx`),
          language:    String(f.language    ?? 'typescript'),
          description: String(f.description ?? 'Generated file'),
          code:        String(f.code        ?? '// Code generation incomplete'),
        }))
      : [{
          filename:    `app/page.tsx`,
          language:    'typescript',
          description: 'Generated application',
          code:        rawText,
        }],

    summary: String(
      parsed.summary ?? `Your ${templateId} application is ready.`
    ),

    features: Array.isArray(parsed.features)
      ? parsed.features.map(String)
      : ['Full-stack ready', 'TypeScript', 'Tailwind CSS'],

    setup_steps: Array.isArray(parsed.setup_steps)
      ? parsed.setup_steps.map(String)
      : ['npm install', 'Configure .env.local', 'npm run dev'],

    env_vars: Array.isArray(parsed.env_vars)
      ? parsed.env_vars.map(String)
      : ['NEXT_PUBLIC_SUPABASE_URL', 'NEXT_PUBLIC_SUPABASE_ANON_KEY'],
  };
}
