// ============================================================
// KOREX BUILDER — Central App Configuration
// ============================================================
// All tunable settings live here. Change a value here and it
// updates everywhere in the app automatically.
// No hunting through multiple files needed!
// ============================================================

// ── AI Models Available on Groq Free Tier ───────────────────
export const GROQ_MODELS = {
  // Primary: Best reasoning, great for complex code
  PRIMARY: process.env.GROQ_MODEL || 'deepseek-r1-distill-llama-70b',

  // Fallback: Activated if primary hits a rate limit
  FALLBACK: process.env.GROQ_FALLBACK_MODEL || 'llama-3.1-70b-versatile',

  // Emergency: Fastest, lowest resource usage
  EMERGENCY: 'llama3-8b-8192',
} as const;

// ── Generation Limits ────────────────────────────────────────
export const GENERATION_CONFIG = {
  // Max tokens per generation (keep ≤6000 for Groq free tier safety)
  MAX_TOKENS: parseInt(process.env.MAX_TOKENS || '6000'),

  // Temperature: 0=deterministic, 1=creative. Code gen works best at 0.3
  TEMPERATURE: 0.3,

  // How many times to retry if the model fails or rate-limits
  MAX_RETRIES: 3,

  // Milliseconds to wait between retries (increases each attempt)
  RETRY_DELAY_MS: 1500,
} as const;

// ── Rate Limiting (Protects your free Groq quota) ────────────
export const RATE_LIMIT = {
  // Max generations per IP per hour
  PER_HOUR: parseInt(process.env.RATE_LIMIT_PER_HOUR || '10'),

  // Window duration in milliseconds (1 hour)
  WINDOW_MS: 60 * 60 * 1000,
} as const;

// ── App Template Definitions ─────────────────────────────────
// Add new templates here — the UI picks them up automatically!
export const APP_TEMPLATES = [
  {
    id: 'portfolio',
    icon: '◈',
    label: 'Portfolio',
    desc: 'Personal / Agency showcase',
    color: '#00f5b4',
    complexity: 'moderate',
    defaultDescription: 'A stunning portfolio website with hero section, about me, projects showcase with filtering, skills grid, testimonials, and contact form with email integration.',
  },
  {
    id: 'saas',
    icon: '⬡',
    label: 'SaaS Dashboard',
    desc: 'Analytics & subscription app',
    color: '#00c8ff',
    complexity: 'high',
    defaultDescription: 'A SaaS dashboard with sidebar navigation, KPI metric cards, interactive charts, user management table, billing/subscription section, and notification system.',
  },
  {
    id: 'ecommerce',
    icon: '◎',
    label: 'E-Commerce',
    desc: 'Store with cart & checkout',
    color: '#a855f7',
    complexity: 'high',
    defaultDescription: 'An e-commerce store with product grid, search and filter, product detail page, sliding cart drawer, checkout flow with Stripe-ready payment form, and order history.',
  },
  {
    id: 'crm',
    icon: '◇',
    label: 'CRM System',
    desc: 'Contacts, deals & pipeline',
    color: '#ff6b35',
    complexity: 'high',
    defaultDescription: 'A CRM system with contacts list, deal kanban pipeline, activity timeline, company profiles, email templates, and revenue analytics dashboard.',
  },
  {
    id: 'blog',
    icon: '✦',
    label: 'Blog Platform',
    desc: 'CMS with auth & comments',
    color: '#f59e0b',
    complexity: 'moderate',
    defaultDescription: 'A blog platform with post listing, category tags, full post view with MDX, author profiles, comment system, newsletter signup, and admin post editor.',
  },
  {
    id: 'custom',
    icon: '⬟',
    label: 'Custom Build',
    desc: 'Describe anything you need',
    color: '#ec4899',
    complexity: 'varies',
    defaultDescription: '',
  },
] as const;

// ── Generation Tiers ─────────────────────────────────────────
export const TIERS = [
  {
    id: 'basic',
    label: 'BASIC',
    desc: 'Frontend UI only',
    color: '#00f5b4',
    files: ['Frontend component', 'Tailwind styles'],
  },
  {
    id: 'pro',
    label: 'PRO',
    desc: 'Full-stack + Database',
    color: '#a855f7',
    files: ['Frontend component', 'API route', 'Supabase SQL schema'],
    badge: 'POPULAR',
  },
  {
    id: 'enterprise',
    label: 'ENTERPRISE',
    desc: 'Complete ecosystem',
    color: '#ff6b35',
    files: ['Frontend', 'API routes', 'DB schema', 'vercel.json', '.env.example', 'README.md'],
    badge: 'COMPLETE',
  },
] as const;

// ── Generation Phase Messages (shown during loading) ─────────
// Tip: Add more phases here to adjust the loading animation timing
export const GENERATION_PHASES = [
  { message: 'Initializing Korex Engine…', progress: 5 },
  { message: 'Analyzing architecture requirements…', progress: 15 },
  { message: 'Selecting optimal AI model…', progress: 22 },
  { message: 'Scaffolding component structure…', progress: 35 },
  { message: 'Generating frontend components…', progress: 48 },
  { message: 'Building API route handlers…', progress: 60 },
  { message: 'Synthesizing database schema…', progress: 72 },
  { message: 'Adding TypeScript types…', progress: 80 },
  { message: 'Optimizing for production…', progress: 88 },
  { message: 'Finalizing deployment config…', progress: 94 },
  { message: 'Packaging your application…', progress: 98 },
] as const;

// ── UI Theme Colors ───────────────────────────────────────────
export const THEME = {
  bg: '#020408',
  surface: 'rgba(255,255,255,0.03)',
  surfaceHover: 'rgba(255,255,255,0.07)',
  border: 'rgba(255,255,255,0.08)',
  borderBright: 'rgba(0,245,180,0.4)',
  neonGreen: '#00f5b4',
  neonBlue: '#00c8ff',
  neonViolet: '#a855f7',
  neonOrange: '#ff6b35',
  text: '#e8eaf0',
  textDim: 'rgba(232,234,240,0.45)',
} as const;
