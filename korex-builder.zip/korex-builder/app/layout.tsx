// ============================================================
// KOREX BUILDER — Root Layout
// ============================================================
// This wraps every page. Add global providers, fonts, and
// metadata here.
// ============================================================

import type { Metadata } from 'next';
import { Orbitron, DM_Mono, Syne } from 'next/font/google';
import './globals.css';

// ── Google Fonts (loaded via Next.js for performance) ─────────
const orbitron = Orbitron({
  subsets: ['latin'],
  weight: ['400', '700', '900'],
  variable: '--font-display',
  display: 'swap',
});

const dmMono = DM_Mono({
  subsets: ['latin'],
  weight: ['300', '400', '500'],
  style: ['normal', 'italic'],
  variable: '--font-mono',
  display: 'swap',
});

const syne = Syne({
  subsets: ['latin'],
  weight: ['400', '600', '700', '800'],
  variable: '--font-body',
  display: 'swap',
});

// ── Page Metadata ─────────────────────────────────────────────
export const metadata: Metadata = {
  title: 'Korex Builder — Zero-Cost AI App Engine',
  description: 'Generate production-ready Next.js full-stack apps in seconds. Free forever. No API key required.',
  keywords: ['AI app generator', 'Next.js', 'Supabase', 'free', 'full-stack'],
  openGraph: {
    title: 'Korex Builder',
    description: 'Generate full-stack apps with AI. Free forever.',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${orbitron.variable} ${dmMono.variable} ${syne.variable}`}>
      <body>{children}</body>
    </html>
  );
}
