// ============================================================
// KOREX BUILDER — Rate Limiter
// ============================================================
// Protects your Groq free-tier quota from being exhausted.
// Uses in-memory tracking (works perfectly on Vercel Hobby).
// No database or Redis needed for basic rate limiting.
//
// HOW TO MODIFY VIA AI PROMPT:
// "Increase the rate limit to 20 requests per hour"
// "Add a whitelist for specific IP addresses"
// "Switch to Supabase-based rate limiting for persistence"
// ============================================================

import { RATE_LIMIT } from '@/config/app.config';

// ── In-memory store for request tracking ─────────────────────
// Key: IP address | Value: Array of request timestamps
// Note: This resets when the server restarts (fine for free tier)
const requestStore = new Map<string, number[]>();

// ── Clean up old entries every 15 minutes ────────────────────
// Prevents memory leaks on long-running servers
if (typeof setInterval !== 'undefined') {
  setInterval(() => {
    const cutoff = Date.now() - RATE_LIMIT.WINDOW_MS;
    for (const [ip, timestamps] of requestStore.entries()) {
      const recent = timestamps.filter(t => t > cutoff);
      if (recent.length === 0) {
        requestStore.delete(ip);
      } else {
        requestStore.set(ip, recent);
      }
    }
  }, 15 * 60 * 1000); // Run every 15 minutes
}

// ── Types ─────────────────────────────────────────────────────
export interface RateLimitResult {
  allowed: boolean;      // Whether this request should proceed
  remaining: number;     // How many requests are left this hour
  resetInMs: number;     // Milliseconds until the window resets
  resetInMin: number;    // Human-readable: minutes until reset
}

// ── Main Rate Check Function ──────────────────────────────────
/**
 * Checks whether an IP address has exceeded the rate limit.
 * If allowed, records the request timestamp.
 *
 * @param ip - The requester's IP address
 * @returns Rate limit status for this request
 */
export function checkRateLimit(ip: string): RateLimitResult {
  const now = Date.now();
  const cutoff = now - RATE_LIMIT.WINDOW_MS;

  // Get existing timestamps for this IP, filtered to current window
  const timestamps = (requestStore.get(ip) ?? []).filter(t => t > cutoff);

  // Calculate how many requests remain
  const used = timestamps.length;
  const remaining = Math.max(0, RATE_LIMIT.PER_HOUR - used);

  // Calculate when the oldest request in the window expires
  const oldestTimestamp = timestamps[0] ?? now;
  const resetInMs = Math.max(0, oldestTimestamp + RATE_LIMIT.WINDOW_MS - now);
  const resetInMin = Math.ceil(resetInMs / 60000);

  // If limit not exceeded, record this request
  if (used < RATE_LIMIT.PER_HOUR) {
    requestStore.set(ip, [...timestamps, now]);
    return {
      allowed: true,
      remaining: remaining - 1, // -1 because we just used one
      resetInMs,
      resetInMin,
    };
  }

  // Rate limit exceeded
  return {
    allowed: false,
    remaining: 0,
    resetInMs,
    resetInMin,
  };
}

/**
 * Extracts the real IP from a Next.js request.
 * Handles proxies (Vercel's CDN) correctly.
 */
export function getClientIp(request: Request): string {
  // Vercel sets these headers with the real client IP
  const forwarded = request.headers.get('x-forwarded-for');
  if (forwarded) {
    return forwarded.split(',')[0].trim();
  }

  const realIp = request.headers.get('x-real-ip');
  if (realIp) return realIp.trim();

  // Fallback for local development
  return '127.0.0.1';
}
