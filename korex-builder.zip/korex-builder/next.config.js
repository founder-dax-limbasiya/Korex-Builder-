/** @type {import('next').NextConfig} */

// ============================================================
// NEXT.JS CONFIGURATION
// ============================================================
// This file controls how Next.js builds and runs your app.
// For most changes, you won't need to touch this file.
// ============================================================

const nextConfig = {
  // Enable React strict mode for better error detection in dev
  reactStrictMode: true,

  // Expose only PUBLIC env vars to the browser.
  // SECRET keys (GROQ_API_KEY, etc.) are NOT listed here —
  // they stay server-side only.
  env: {
    NEXT_PUBLIC_APP_URL: process.env.NEXT_PUBLIC_APP_URL,
    NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL,
    NEXT_PUBLIC_SUPABASE_ANON_KEY: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  },
};

module.exports = nextConfig;
