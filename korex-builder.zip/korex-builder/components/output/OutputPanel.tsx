// ============================================================
// KOREX BUILDER — Output Panel
// ============================================================
// Displays the generated code with:
// - Summary & feature list
// - Multi-file tab switcher
// - Syntax-highlighted code viewer
// - Copy & download buttons per file
// - "Download All" bulk download
// - Setup steps & env vars
//
// HOW TO MODIFY VIA AI PROMPT:
// "Add a 'Deploy to Vercel' button that opens Vercel's import"
// "Add syntax highlighting with highlight.js"
// "Show a diff view comparing before/after file changes"
// ============================================================

'use client';

import { useState } from 'react';
import type { ParsedGenerationResult } from '@/lib/response-parser';

interface OutputPanelProps {
  result: ParsedGenerationResult;
  meta?: {
    model: string;
    tokensUsed: number;
    generationTime: number;
    totalTime: number;
    templateId: string;
    tierId: string;
  };
  onReset: () => void;
}

export default function OutputPanel({ result, meta, onReset }: OutputPanelProps) {
  const [activeFileIndex, setActiveFileIndex] = useState(0);
  const [copyState, setCopyState] = useState<'idle' | 'copied'>('idle');

  const activeFile = result.files[activeFileIndex];

  // ── Copy to clipboard ─────────────────────────────────────
  const handleCopy = () => {
    navigator.clipboard.writeText(activeFile?.code ?? '').then(() => {
      setCopyState('copied');
      setTimeout(() => setCopyState('idle'), 2000);
    });
  };

  // ── Download single file ──────────────────────────────────
  const handleDownload = (file: typeof activeFile) => {
    const blob = new Blob([file.code], { type: 'text/plain;charset=utf-8' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = file.filename.split('/').pop() ?? file.filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // ── Download all files (staggered to avoid browser block) ──
  const handleDownloadAll = () => {
    result.files.forEach((file, i) => {
      setTimeout(() => handleDownload(file), i * 200);
    });
  };

  return (
    <div className="animate-fade-up" style={{ maxWidth: '960px', margin: '0 auto', padding: '0 20px' }}>

      {/* ── Success Banner ─────────────────────────────────── */}
      <div className="glass-bright" style={{ borderRadius: '14px', padding: '20px 24px', marginBottom: '16px' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: '16px', flexWrap: 'wrap' }}>

          {/* Check icon */}
          <div style={{
            width: 40, height: 40, borderRadius: '10px', flexShrink: 0,
            background: 'linear-gradient(135deg, var(--neon-green), var(--neon-blue))',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: '16px', fontWeight: 700, color: '#020408',
            boxShadow: 'var(--glow-green)',
          }}>
            ✓
          </div>

          <div style={{ flex: 1, minWidth: '200px' }}>
            <div style={{
              fontFamily: 'var(--font-display)', fontSize: '11px', letterSpacing: '0.12em',
              marginBottom: '5px',
            }} className="neon-green">
              APPLICATION GENERATED SUCCESSFULLY
            </div>
            <div style={{ fontSize: '13px', color: 'var(--text-dim)', lineHeight: 1.6 }}>
              {result.summary}
            </div>
          </div>

          <button
            onClick={handleDownloadAll}
            style={{
              padding: '10px 20px', borderRadius: '8px', flexShrink: 0,
              border: '1px solid rgba(0,245,180,0.4)',
              background: 'rgba(0,245,180,0.08)',
              fontFamily: 'var(--font-mono)', fontSize: '10px', letterSpacing: '0.1em',
              color: 'var(--neon-green)', cursor: 'pointer', transition: 'all 0.2s',
            }}
          >
            ↓ DOWNLOAD ALL ({result.files.length} files)
          </button>
        </div>

        {/* Meta info row */}
        {meta && (
          <div style={{
            marginTop: '14px', paddingTop: '14px', borderTop: '1px solid var(--border)',
            display: 'flex', gap: '20px', flexWrap: 'wrap',
          }}>
            {[
              { label: 'Model',   value: meta.model.split('-').slice(0, 2).join('-') },
              { label: 'Tokens',  value: `${meta.tokensUsed.toLocaleString()} used` },
              { label: 'Time',    value: `${(meta.totalTime / 1000).toFixed(1)}s` },
              { label: 'Files',   value: `${result.files.length} generated` },
            ].map(({ label, value }) => (
              <div key={label} style={{ fontSize: '10px', fontFamily: 'var(--font-mono)', color: 'var(--text-dim)' }}>
                <span style={{ color: 'var(--neon-green)' }}>{label}: </span>{value}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ── Features + Env Vars ────────────────────────────── */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px', marginBottom: '16px' }}>

        {result.features.length > 0 && (
          <div className="glass" style={{ borderRadius: '12px', padding: '16px' }}>
            <div style={{ fontSize: '10px', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em', color: 'var(--neon-green)', marginBottom: '12px' }}>
              ◈ FEATURES INCLUDED
            </div>
            <div className="stagger">
              {result.features.map((feature, i) => (
                <div key={i} className="animate-fade-in" style={{
                  fontSize: '12px', color: 'var(--text-dim)', fontFamily: 'var(--font-mono)',
                  marginBottom: '6px', display: 'flex', alignItems: 'flex-start', gap: '8px',
                }}>
                  <span style={{ color: 'var(--neon-green)', fontSize: '8px', flexShrink: 0, marginTop: '4px' }}>▸</span>
                  {feature}
                </div>
              ))}
            </div>
          </div>
        )}

        {result.env_vars.length > 0 && (
          <div className="glass" style={{ borderRadius: '12px', padding: '16px' }}>
            <div style={{ fontSize: '10px', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em', color: 'var(--neon-blue)', marginBottom: '12px' }}>
              ◎ REQUIRED ENV VARIABLES
            </div>
            <div className="stagger">
              {result.env_vars.map((envVar, i) => (
                <div key={i} className="animate-fade-in" style={{
                  fontSize: '11px', fontFamily: 'var(--font-mono)', marginBottom: '6px',
                  color: '#7dd3fc',
                }}>
                  {envVar}
                  <span style={{ color: 'var(--text-dim)' }}>=</span>
                  <span style={{ color: 'var(--text-dim)', opacity: 0.6 }}>your_value</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* ── File Viewer ────────────────────────────────────── */}
      {result.files.length > 0 && (
        <div className="glass" style={{ borderRadius: '14px', overflow: 'hidden', marginBottom: '16px' }}>

          {/* File tabs */}
          <div style={{
            display: 'flex', overflowX: 'auto', borderBottom: '1px solid var(--border)',
            background: 'rgba(0,0,0,0.4)',
          }}>
            {result.files.map((file, i) => (
              <button
                key={i}
                onClick={() => setActiveFileIndex(i)}
                style={{
                  padding: '10px 18px', border: 'none', cursor: 'pointer',
                  fontFamily: 'var(--font-mono)', fontSize: '11px', whiteSpace: 'nowrap',
                  borderRight: '1px solid var(--border)',
                  background: activeFileIndex === i ? 'rgba(0,245,180,0.08)' : 'transparent',
                  color: activeFileIndex === i ? 'var(--neon-green)' : 'var(--text-dim)',
                  borderBottom: activeFileIndex === i ? '2px solid var(--neon-green)' : '2px solid transparent',
                  transition: 'all 0.15s',
                  flexShrink: 0,
                }}
              >
                {file.filename.split('/').pop()}
              </button>
            ))}
          </div>

          {/* File header toolbar */}
          <div style={{
            padding: '12px 18px', borderBottom: '1px solid var(--border)',
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
            background: 'rgba(0,0,0,0.25)', flexWrap: 'wrap', gap: '10px',
          }}>
            <div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: '12px', color: 'var(--neon-blue)' }}>
                {activeFile?.filename}
              </div>
              <div style={{ fontSize: '10px', color: 'var(--text-dim)', fontFamily: 'var(--font-mono)', marginTop: '2px' }}>
                {activeFile?.description}
              </div>
            </div>

            <div style={{ display: 'flex', gap: '8px' }}>
              <button
                onClick={handleCopy}
                style={{
                  padding: '6px 14px', borderRadius: '6px', cursor: 'pointer',
                  border: '1px solid var(--border)', background: 'transparent',
                  fontFamily: 'var(--font-mono)', fontSize: '10px', letterSpacing: '0.08em',
                  color: copyState === 'copied' ? 'var(--neon-green)' : 'var(--text-dim)',
                  transition: 'all 0.2s',
                }}
              >
                {copyState === 'copied' ? '✓ COPIED' : '⎘ COPY'}
              </button>
              <button
                onClick={() => activeFile && handleDownload(activeFile)}
                style={{
                  padding: '6px 14px', borderRadius: '6px', cursor: 'pointer',
                  border: '1px solid rgba(0,245,180,0.3)',
                  background: 'rgba(0,245,180,0.06)',
                  fontFamily: 'var(--font-mono)', fontSize: '10px', letterSpacing: '0.08em',
                  color: 'var(--neon-green)', transition: 'all 0.2s',
                }}
              >
                ↓ SAVE FILE
              </button>
            </div>
          </div>

          {/* Code content */}
          <div
            className="code-scroll"
            style={{
              background: 'rgba(0,0,0,0.6)',
              padding: '20px 24px',
              maxHeight: '520px',
              overflowY: 'auto',
              overflowX: 'auto',
            }}
          >
            <pre style={{
              margin: 0,
              fontFamily: 'var(--font-mono)',
              fontSize: '12.5px',
              lineHeight: '1.75',
              color: '#a8ffdc',
              whiteSpace: 'pre-wrap',
              wordBreak: 'break-word',
            }}>
              {activeFile?.code ?? ''}
            </pre>
          </div>

          {/* Code line count footer */}
          <div style={{
            padding: '8px 18px', borderTop: '1px solid var(--border)',
            background: 'rgba(0,0,0,0.3)',
            display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          }}>
            <span style={{ fontSize: '9px', fontFamily: 'var(--font-mono)', color: 'var(--text-dim)' }}>
              {activeFile?.language?.toUpperCase()} · {(activeFile?.code ?? '').split('\n').length} lines
            </span>
            <span style={{ fontSize: '9px', fontFamily: 'var(--font-mono)', color: 'var(--text-dim)' }}>
              {((activeFile?.code ?? '').length / 1024).toFixed(1)} KB
            </span>
          </div>
        </div>
      )}

      {/* ── Setup Steps ────────────────────────────────────── */}
      {result.setup_steps.length > 0 && (
        <div className="glass" style={{ borderRadius: '12px', padding: '20px', marginBottom: '20px' }}>
          <div style={{ fontSize: '10px', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em', color: 'var(--neon-violet)', marginBottom: '16px' }}>
            ◇ SETUP INSTRUCTIONS
          </div>
          <div className="stagger">
            {result.setup_steps.map((step, i) => (
              <div key={i} className="animate-fade-in" style={{
                display: 'flex', gap: '14px', alignItems: 'flex-start', marginBottom: '12px',
              }}>
                <div style={{
                  width: 22, height: 22, borderRadius: '50%', flexShrink: 0,
                  background: 'rgba(168,85,247,0.12)', border: '1px solid rgba(168,85,247,0.3)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: '9px', fontFamily: 'var(--font-display)', color: 'var(--neon-violet)',
                  fontWeight: 700,
                }}>
                  {i + 1}
                </div>
                <div style={{ fontSize: '12px', color: 'var(--text-dim)', fontFamily: 'var(--font-mono)', lineHeight: 1.65, paddingTop: '2px' }}>
                  {step}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ── Reset / Build Again ─────────────────────────────── */}
      <div style={{ textAlign: 'center', paddingBottom: '20px' }}>
        <button
          onClick={onReset}
          style={{
            padding: '11px 32px', borderRadius: '8px', cursor: 'pointer',
            border: '1px solid var(--border)', background: 'transparent',
            fontFamily: 'var(--font-mono)', fontSize: '11px', letterSpacing: '0.1em',
            color: 'var(--text-dim)', transition: 'all 0.2s',
          }}
          onMouseEnter={e => {
            (e.currentTarget as HTMLElement).style.borderColor = 'var(--border-bright)';
            (e.currentTarget as HTMLElement).style.color = 'var(--neon-green)';
          }}
          onMouseLeave={e => {
            (e.currentTarget as HTMLElement).style.borderColor = 'var(--border)';
            (e.currentTarget as HTMLElement).style.color = 'var(--text-dim)';
          }}
        >
          ⟳ BUILD ANOTHER APP
        </button>
      </div>
    </div>
  );
}
